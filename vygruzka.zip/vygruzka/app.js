const express = require('express');
const multer = require('multer'); 
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 4000;

const storage = multer.diskStorage({
    destination: 'uploads/',
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage });

app.use('/uploads', express.static('uploads'));

app.get('/', (req, res) => {
    res.send(
        `<form action="/upload" method="POST" enctype="multipart/form-data">
            <input type="file" name="filedata">
            <button>Загрузить</button>
        </form>
        <a href="/list">Все файлы</a>`
    );
});
app.post('/upload', upload.single('filedata'), (req, res) => {
    res.redirect('/list');
});

app.get('/list', (req, res) => {
    fs.readdir('uploads/', (err, files) => {
        if (err) return res.send('Ошибка');

        let list = '';
        files.forEach(file => {
            const fileUrl = `/uploads/${file}`;
            list +=
                `<div>
                    <strong>${file}</strong>
                    <a href="${fileUrl}" download>Скачать</a>
                </div>`;
        });

        res.send(`
            <h1>Файлы (${files.length})</h1>
            ${list}
            <a href="/">Назад</a>
        `);
    });
});
app.listen(PORT,() =>{
    console.log(`Сервер:http:/localhost:${PORT}`);
    if (!fs.existsSync(`uploads`)) fs.mkdirSync(`uploads`);
});